import streamlit as st

st.title("✅ Arbitrage Streamlit Test")
st.write("If you're seeing this, your deployment is working!")
