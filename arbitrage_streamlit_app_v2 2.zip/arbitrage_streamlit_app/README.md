# Arbitrage Streamlit Dashboard

This project is a Streamlit-based dashboard for detecting arbitrage opportunities across sports betting bookmakers using live odds from OddsAPI.

## Features
- Supports multiple sports (Football, Tennis, Basketball, Horse Racing)
- Detects arbitrage opportunities across selected or all bookmakers
- Easy to use interface
- Configurable odds API key, regions, and markets

## Getting Started

1. Install dependencies:
```
pip install -r requirements.txt
```

2. Run the app:
```
streamlit run dashboard_app.py
```

3. Set your API key and preferences in `config.py`.

## Deployment

You can deploy this project on [Streamlit Cloud](https://streamlit.io/cloud).

## Files

- `dashboard_app.py`: Main Streamlit dashboard
- `odds_api.py`: Fetches odds data from the API
- `arbitrage_engine.py`: Detects arbitrage opportunities
- `config.py`: Settings like API key, regions, sports, bookmakers
