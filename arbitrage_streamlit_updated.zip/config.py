API_KEY = "817c309e5d37829ba411d488fdab5e2a"
REGIONS = "uk"  # You can use 'us', 'uk', 'eu'
SPORTS = {
    "football": "soccer_epl",
    "tennis": "tennis",
    "basketball": "basketball_nba",
    "rugby": "rugby_union",
    "horse racing": "horse_racing_uk"
}
MARKET = "h2h"
